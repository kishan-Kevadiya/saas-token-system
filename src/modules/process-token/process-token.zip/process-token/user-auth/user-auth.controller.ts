import { type NextFunction, type Request } from 'express';
import { HttpStatusCode } from 'axios';
import { type CurrentUserDto } from '../company-auth/dto/current-user.dto';
import UserAuthService from './user-auth.service';
import Api from '@/lib/api';
import { type CustomResponse } from '@/types/common.type';

export default class UserAuthController extends Api {
  private readonly userAuthService: UserAuthService;

  constructor(userAuthService?: UserAuthService) {
    super();
    this.userAuthService = userAuthService ?? new UserAuthService();
  }

  public login = async (
    req: Request,
    res: CustomResponse<CurrentUserDto>,
    next: NextFunction
  ) => {
    try {
      const user = await this.userAuthService.login(
        req.body,
        res.locals.currentUser
      );
      this.send(res, user, HttpStatusCode.Ok, 'Login successfully');
    } catch (e) {
      next(e);
    }
  };

  public getUserDetailsByToken = async (
    _req: Request,
    res: CustomResponse<CurrentUserDto>,
    next: NextFunction
  ) => {
    try {
      const currentUser = res.locals.currentUser;
      const userResponse = this.userAuthService.mapUserResponse(currentUser);

      return this.send(res, userResponse, HttpStatusCode.Ok);
    } catch (e) {
      next(e);
    }
  };
}
