import { type Request, type NextFunction } from 'express';
import { HttpStatusCode } from 'axios';
import ButtonService from './button.service';
import { type ButtonDto } from './dto/button.dto';
import Api from '@/lib/api';
import { type CustomResponse } from '@/types/common.type';

export default class ButtonController extends Api {
  private readonly buttonService: ButtonService;

  constructor(buttonService?: ButtonService) {
    super();
    this.buttonService = buttonService ?? new ButtonService();
  }

  public getButtons = async (
    req: Request,
    res: CustomResponse<ButtonDto>,
    _next: NextFunction
  ) => {
    try {
      const buttons = await this.buttonService.getButtons(
        res.locals.currentUser
      );

      this.send(res, buttons, HttpStatusCode.Ok, 'Buttons get sucessfully.');
    } catch (e) {
      this.send(
        res,
        null,
        HttpStatusCode.InternalServerError,
        'An unexpected error occurred',
        e
      );
    }
  };
}
