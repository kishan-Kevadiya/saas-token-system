import { type UserResponseDto } from '../user-auth/dto/current-user-auth.dto';
import { type ButtonDto } from './dto/button.dto';
import prisma from '@/lib/prisma';

export default class ButtonService {
  public async getButtons(currentUser: UserResponseDto): Promise<ButtonDto[]> {
    const button = await prisma.ht_buttons.findMany({
      where: {
        company_id: currentUser.company.id,
        dept_id: currentUser.department?.id,
        deleted_at: null,
      },
      select: {
        hash_id: true,
        name: true,
        created_at: true,
      },
    });

    return button.map((buttons) => ({
      id: buttons.hash_id,
      name: buttons.name,
      created_at: buttons.created_at.toISOString(),
    }));
  }
}
