import ButtonService from '../button.service';
import { type UserResponseDto } from '../../user-auth/dto/current-user-auth.dto';
import prisma from '@/lib/prisma';

jest.mock('@/lib/prisma', () => ({
  ht_buttons: {
    findMany: jest.fn(),
  },
}));

describe('ButtonService', () => {
  const service = new ButtonService();

  const currentUser: UserResponseDto = {
    id: '1',
    name: 'Test User',
    email: 'test@example.com',
    company: {
      id: 101,
      company_name: 'Test Company',
    },
    department: {
      id: 202,
      dept_english_name: 'english_name',
      dept_hindi_name: 'hindi_name',
      dept_regional_name: 'regional_name',
    },
    contact_no: '7845122145',
    username: 'user_name',
    data: undefined,
    counter: undefined,
    ip: '21.21.1',
    is_active: 0,
    created_at: new Date(),
    updated_at: null,
  };

  const mockResponse = [
    {
      hash_id: 'btn_123',
      name: 'Submit',
      created_at: new Date('2023-08-01T10:00:00.000Z'),
    },
    {
      hash_id: 'btn_456',
      name: 'Cancel',
      created_at: new Date('2023-08-02T12:00:00.000Z'),
    },
  ];

  it('should return  button list successfully.', async () => {
    (prisma.ht_buttons.findMany as jest.Mock).mockResolvedValue(mockResponse);

    const result = await service.getButtons(currentUser);

    expect(prisma.ht_buttons.findMany).toHaveBeenCalledWith({
      where: {
        company_id: 101,
        dept_id: 202,
        deleted_at: null,
      },
      select: {
        hash_id: true,
        name: true,
        created_at: true,
      },
    });

    expect(result).toEqual([
      {
        id: 'btn_123',
        name: 'Submit',
        created_at: '2023-08-01T10:00:00.000Z',
      },
      {
        id: 'btn_456',
        name: 'Cancel',
        created_at: '2023-08-02T12:00:00.000Z',
      },
    ]);
  });

  it('should return empty array if no buttons are found', async () => {
    (prisma.ht_buttons.findMany as jest.Mock).mockResolvedValue([]);

    const result = await service.getButtons(currentUser);
    expect(result).toEqual([]);
  });

  it('should handle not department found', async () => {
    const userWithoutDept = { ...currentUser, department: null };
    (prisma.ht_buttons.findMany as jest.Mock).mockResolvedValue([]);

    await service.getButtons(userWithoutDept);

    expect(prisma.ht_buttons.findMany).toHaveBeenCalledWith({
      where: {
        company_id: 101,
        dept_id: undefined,
        deleted_at: null,
      },
      select: {
        hash_id: true,
        name: true,
        created_at: true,
      },
    });
  });
});
