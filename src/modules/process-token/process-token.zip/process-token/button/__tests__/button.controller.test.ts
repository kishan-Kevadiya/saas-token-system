import { HttpStatusCode } from 'axios';
import type ButtonService from '../button.service';
import ButtonController from '../button.controller';

describe('ButtonController', () => {
  let mockService: jest.Mocked<ButtonService>;
  let controller: ButtonController;
  let req: any;
  let res: any;
  let next: jest.Mock;

  beforeEach(() => {
    mockService = {
      getButtons: jest.fn(),
    } as unknown as jest.Mocked<ButtonService>;

    controller = new ButtonController(mockService);

    req = {};
    res = {
      locals: {
        currentUser: { id: 1, name: 'Test User' },
      },
      status: jest.fn().mockReturnThis(),
      json: jest.fn().mockReturnThis(),
    };

    (controller as any).send = jest.fn();

    next = jest.fn();
  });

  it('should return buttons successfully', async () => {
    const mockButtons = [
      { id: '1', name: 'Submit', created_at: '' },
      { id: '2', name: 'Cancel', created_at: '' },
    ];

    mockService.getButtons.mockResolvedValue(mockButtons);

    await controller.getButtons(req, res, next);

    expect(mockService.getButtons).toHaveBeenCalledWith(res.locals.currentUser);
    expect((controller as any).send).toHaveBeenCalledWith(
      res,
      mockButtons,
      HttpStatusCode.Ok,
      'Buttons get sucessfully.'
    );
  });

  it('should handle errors and return 500', async () => {
    const error = new Error('Something went wrong');
    mockService.getButtons.mockRejectedValue(error);

    await controller.getButtons(req, res, next);

    expect(mockService.getButtons).toHaveBeenCalledWith(res.locals.currentUser);
    expect((controller as any).send).toHaveBeenCalledWith(
      res,
      null,
      HttpStatusCode.InternalServerError,
      'An unexpected error occurred',
      error
    );
  });
});
