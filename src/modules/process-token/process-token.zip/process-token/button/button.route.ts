import { Router } from 'express';
import ButtonController from './button.controller';

const buttons: Router = Router();
const controller = new ButtonController();

/**
 * CompanyButtons
 * @typedef {object} CompanyButtons
 * @property {string} id - hash id of the button
 * @property {string} name - name of the button
 * @property {string} created_at - created data and time of the button
 */

/**
 * GET /process-token/buttons/
 * @summary Get buttons
 * @tags company-buttons
 * @security Authorization
 * @return {CompanyButtons[]} 200 - company buttons retrieved
 * @return 401 - Unauthorized
 * @return 500 - Internal server error
 * @return 404 - Not found
 */
buttons.get('/', controller.getButtons);

export default buttons;
