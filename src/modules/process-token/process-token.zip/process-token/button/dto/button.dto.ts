import { IsString } from 'class-validator';

export class ButtonDto {
  @IsString()
  id: string;

  @IsString()
  name: string;

  @IsString()
  created_at: string;
}
