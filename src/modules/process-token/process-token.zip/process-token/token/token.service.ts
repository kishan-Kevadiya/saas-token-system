import { TokenStatus } from '@prisma/client';
import { type UserResponseDto } from '../user-auth/dto/current-user-auth.dto';
import { type tokenStatusUpdateDto } from './dto/token-update-status-input.dto';
import { type TokenStatusDto } from './dto/token-update-response.dto';
import { type TokenDto } from './dto/token.dto';
import { HttpBadRequestError } from '@/lib/errors';
import { CompanyTokenManager } from '@/utils/redis-token-manager';
import prisma from '@/lib/prisma';

async function updateToken(
  tokenId: string,
  status: TokenStatus,
  reason?: string
): Promise<TokenStatusDto> {
  const now = new Date();
  const updateData: any = {
    token_status: status,
    updated_at: now,
    ...(reason && { reason }),
  };

  if (status === TokenStatus.ACTIVE) updateData.hold_out_time = now;
  if (status === TokenStatus.HOLD) updateData.hold_in_time = now;
  if (status === TokenStatus.COMPLETED) updateData.token_out_time = now;

  const updated = await prisma.tokens.update({
    where: { hash_id: tokenId },
    data: updateData,
    select: {
      hash_id: true,
      token_status: true,
      company_id: true,
      counter_number_id: true,
      company: {
        select: {
          hash_id: true,
        },
      },
      token_calling_time: true,
      token_out_time: true,
      hold_in_time: true,
      hold_out_time: true,
      user_id: true,
      reason: true,
      ht_user: { select: { name: true } },
    },
  });

  const tokenManager = new CompanyTokenManager(updated.company.hash_id);
  await tokenManager.updateToken(updated.hash_id, {
    token_id: updated.hash_id,
    token_status: updated.token_status,
  });

  return {
    id: updated.hash_id,
    token_status: updated.token_status,
    reason: updated.reason,
    company_id: updated.company_id,
    counter_no: updated.counter_number_id,
    user_id: updated.user_id,
    user_name: updated.ht_user?.name ?? null,
    hold_in_time: updated.hold_in_time,
    hold_out_time: updated.hold_out_time,
    token_calling_time: updated.token_calling_time,
    token_out_time: updated.token_out_time,
  };
}

export default class TokenService {
  public async tokenStatus(
    hashId: string,
    data: tokenStatusUpdateDto,
    currentUser: UserResponseDto
  ): Promise<TokenStatusDto> {
    const token = await prisma.tokens.findUniqueOrThrow({
      where: {
        hash_id: hashId,
        deleted_at: null,
        // company_id: currentUser.company.id,
      },
    });

    switch (data.status) {
      case 'PENDING': {
        if (token.token_status !== TokenStatus.ACTIVE) {
          throw new HttpBadRequestError(
            'Only ACTIVE tokens can be moved to PENDING!'
          );
        }
        return await updateToken(
          token.hash_id,
          TokenStatus.PENDING,
          data.reason
        );
      }

      case 'HOLD': {
        if (token.token_status !== TokenStatus.ACTIVE) {
          throw new HttpBadRequestError(
            'Only ACTIVE tokens can be moved to HOLD!'
          );
        }

        return await updateToken(token.hash_id, TokenStatus.HOLD, data.reason);
      }

      case 'BREAK': {
        if (token.token_status !== TokenStatus.ACTIVE) {
          throw new HttpBadRequestError(
            'Only ACTIVE tokens can be marked as COMPLETED!'
          );
        }

        return await updateToken(
          token.hash_id,
          TokenStatus.COMPLETED,
          data.reason
        );
      }

      case 'WAITING': {
        if (token.token_status !== TokenStatus.PENDING) {
          throw new HttpBadRequestError(
            'Only PENDING tokens can be marked as WAITING!'
          );
        }

        return await updateToken(
          token.hash_id,
          TokenStatus.WAITING,
          data.reason
        );
      }

      case 'ACTIVE': {
        if (token.token_status !== TokenStatus.HOLD) {
          throw new HttpBadRequestError(
            'Only HOLD tokens can be marked as ACTIVE!'
          );
        }

        return await updateToken(
          token.hash_id,
          TokenStatus.ACTIVE,
          data.reason
        );
      }

      default:
        throw new HttpBadRequestError(`Invalid status value: ${data.status}`);
    }
  }

  public async getTokenById(
    hashId: string,
    currentUser: UserResponseDto
  ): Promise<TokenDto> {
    // const tokens = new CompanyTokenManager(currentUser.company.id);
    const tokens = new CompanyTokenManager('ht-comp-001');

    const tokeneDetails = tokens.getTokenById(hashId);

    if (!tokeneDetails) {
      throw new HttpBadRequestError('Invalid token');
    }

    return await tokeneDetails;
  }
}
