import { IsNotEmpty, IsOptional, IsString } from 'class-validator';

export class tokenStatusUpdateDto {
  @IsNotEmpty()
  @IsString()
  status: string;

  @IsOptional()
  @IsString()
  reason?: string;
}
