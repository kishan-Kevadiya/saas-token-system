import { TokenStatus } from '@prisma/client';
import {
  IsDate,
  IsEnum,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator';

export class TokenStatusDto {
  @IsString()
  id: string;

  @IsEnum(TokenStatus)
  token_status: TokenStatus;

  @IsNumber()
  counter_no: number | null;

  @IsNumber()
  company_id: number;

  @IsNumber()
  user_id: number | null;

  @IsString()
  user_name: string | null;

  @IsDate()
  hold_in_time: Date | null;

  @IsDate()
  hold_out_time: Date | null;

  @IsDate()
  token_calling_time: Date | null;

  @IsDate()
  token_out_time: Date | null;

  @IsOptional()
  @IsString()
  reason: string | null;
}
