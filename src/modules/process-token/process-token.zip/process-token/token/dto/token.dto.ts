import { TokenStatus } from '@prisma/client';
import { IsDate, IsEnum, IsJSON, IsNumber, IsString } from 'class-validator';

export class TokenDto {
  @IsString()
  token_id: string;

  @IsString()
  token_abbreviation: string;

  @IsEnum(TokenStatus)
  token_status: TokenStatus;

  @IsNumber()
  series_id: number;

  @IsString()
  token_series_number: string;

  @IsString()
  customer_name: string | null;

  @IsDate()
  token_date: Date;

  @IsDate()
  token_calling_time: Date | null;

  @IsDate()
  token_out_time: Date | null;

  @IsDate()
  token_generate_time: Date;

  @IsString()
  customer_mobile_number: string | null;

  @IsJSON()
  form_data: JSON | null;

  @IsNumber()
  token_number: number;

  @IsNumber()
  language_id: number;

  @IsNumber()
  company_id: number;

  @IsNumber()
  priority: number;
}
