import { type Request, type NextFunction } from 'express';
import { HttpStatusCode } from 'axios';
import TokenService from './token.service';
import { type TokenStatusDto } from './dto/token-update-response.dto';
import { type TokenDto } from './dto/token.dto';
import { type CustomResponse } from '@/types/common.type';
import Api from '@/lib/api';

export default class TokenController extends Api {
  private readonly tokenService: TokenService;

  constructor(tokenService?: TokenService) {
    super();
    this.tokenService = tokenService ?? new TokenService();
  }

  public updateTokenStatus = async (
    req: Request,
    res: CustomResponse<TokenStatusDto>,
    _next: NextFunction
  ) => {
    try {
      await this.tokenService.tokenStatus(
        req.params.id,
        req.body,
        res.locals.currentUser
      );

      this.send(
        res,
        null,
        HttpStatusCode.Ok,
        'Token status updated successfully.'
      );
    } catch (e) {
      console.log('error', e);
      if (e.message === 'No tokens found') {
        this.send(res, null, HttpStatusCode.NotFound, 'No token found!');
      } else if (e.message === 'Invalid status') {
        this.send(res, null, HttpStatusCode.BadRequest, e.message);
      } else if (e.message === 'Invalid current status') {
        this.send(res, null, HttpStatusCode.BadRequest, e.message);
      } else {
        this.send(
          res,
          null,
          HttpStatusCode.InternalServerError,
          'An unexpected error occurred',
          e
        );
      }
    }
  };

  public getTokenById = async (
    req: Request,
    res: CustomResponse<TokenDto>,
    _next: NextFunction
  ) => {
    try {
      const token = await this.tokenService.getTokenById(
        req.params.id,
        res.locals.currentUser
      );

      this.send(res, token, HttpStatusCode.Ok, 'Token details');
    } catch (e) {
      console.log('e :>> ', e);
      if (e.message === 'No token found') {
        this.send(res, null, HttpStatusCode.NotFound, 'Token not found!');
      } else {
        this.send(
          res,
          null,
          HttpStatusCode.InternalServerError,
          'An unexpected error occurred',
          e
        );
      }
    }
  };
}
