import { Router } from 'express';
import TokenController from './token.controller';
import { tokenStatusUpdateDto } from './dto/token-update-status-input.dto';
import RequestValidator from '@/middlewares/request-validator';

const token: Router = Router();
const controller = new TokenController();

/**
 * TokenStatusResponse
 * @typedef {object} TokenStatusResponse
 * @property {string} hash_id - hash id of the token
 * @property {number} counter_no - hash id of the counter
 * @property {('PENDING' | 'HOLD' | 'ACTIVE' | 'TRANSFER' | 'WAITING' | 'COMPLETED')} token_status - token status
 * @property {number} user_id - id of the user
 */

/**
 * TokenStatusInputBody
 * @typedef {object} TokenStatusInputBody
 * @property {string} status - token status
 * @property {string} reason - reason for holding the token
 */

/**
 * TokenResponse
 * @typedef {object} TokenResponse
 * @property {string} token_id -  token hash_id
 * @property {string} token_abbreviation - Abbreviated token code
 * @property {('PENDING' | 'HOLD' | 'ACTIVE' | 'TRANSFER' | 'WAITING' | 'COMPLETED')} token_status - status of the token
 * @property {number} series_id - ID of the token series
 * @property {string} token_series_number - Unique series number within the series
 * @property {string} customer_name - Name of the customer
 * @property {Date} token_date - Date of the token
 * @property {Date} token_calling_time - Time when the token was called
 * @property {Date} token_out_time - Time when the token was completed
 * @property {Date} token_generate_data - Time when the token was generated
 * @property {string} customer_mobile_number - Customer's mobile number
 * @property {object} form_data - form data (JSON)
 * @property {number} token_number - Token number
 * @property {number} language_id - Language Id
 * @property {number} company_id - company Id
 * @property {number} priority - Priority level of the token
 */

/**
 * POST /process-token/token-status/{id}
 * @summary Update token status
 * @tags token-status
 * @security Authorization
 * @param {string} id.path.required - hash id of the token
 * @param {TokenStatusInputBody} request.body.required
 * @return {TokenStatusResponse} 200 - Token status updated successfully
 * @return 400 - Bad request
 * @return 401 - Unauthorized
 * @return 404 - Not found
 * @return 500 - Internal server error
 */
token.post(
  '/:id',
  RequestValidator.validate(tokenStatusUpdateDto),
  controller.updateTokenStatus
);

/**
 * GET /process-token/token-status/{id}
 * @summary Get token by id
 * @tags token-status
 * @security Authorization
 * @param {string} id.path.required - hash id of the token
 * @return {TokenResponse} 200 - token data retrieved
 * @return 401 - Unauthorized
 * @return 500 - Internal server error
 * @return 404 - Not found
 */
token.get('/:id', controller.getTokenById);

export default token;
