import { type NextFunction, type Request } from 'express';
import { HttpStatusCode } from 'axios';
import AuthService from './auth.service';
import { type CurrentUserDto } from './dto/current-user.dto';
import { type CustomResponse } from '@/types/common.type';
import Api from '@/lib/api';

export default class AuthController extends Api {
  private readonly authService: AuthService;

  constructor(authService?: AuthService) {
    super();
    this.authService = authService ?? new AuthService();
  }

  public login = async (
    req: Request,
    res: CustomResponse<CurrentUserDto>,
    next: NextFunction
  ) => {
    try {
      const user = await this.authService.login(req.body);
      this.send(res, user, HttpStatusCode.Ok, 'Login successfully');
    } catch (e) {
      next(e);
    }
  };

  public getUserDetailsByToken = async (
    _req: Request,
    res: CustomResponse<CurrentUserDto>,
    next: NextFunction
  ) => {
    try {
      const currentUser = res.locals.currentUser;
      const userResponse = this.authService.mapUserResponse(currentUser);

      return this.send(
        res,
        userResponse,
        HttpStatusCode.Ok,
        'Authorized user details fetched successfully'
      );
    } catch (e) {
      next(e);
    }
  };
}
