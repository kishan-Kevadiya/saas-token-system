import { type Request, type Response, type NextFunction } from 'express';
import { HttpStatusCode } from 'axios';
import AuthController from '../auth.controller';
import AuthService from '../auth.service';

describe('AuthController', () => {
  let controller: AuthController;
  let service: AuthService;
  let mockReq: Partial<Request>;
  let mockRes: Partial<Response & { locals: { currentUser?: any } }>;
  let mockNext: NextFunction;

  beforeEach(() => {
    service = new AuthService();
    controller = new AuthController(service);

    mockReq = {
      body: {
        asccode: 'A123',
        password: 'testpass',
      },
    };

    mockRes = {
      locals: {},
      status: jest.fn().mockReturnThis(),
      json: jest.fn().mockReturnThis(),
    };

    mockNext = jest.fn();
  });

  describe('login', () => {
    it('should return token and user if login is successful', async () => {
      const mockUser = { id: 'abc', name: 'Test' };
      const mockToken = 'mocked.token.value';

      jest.spyOn(service, 'login').mockResolvedValue({
        token: mockToken,
        user: mockUser,
      });

      await controller.login(mockReq as Request, mockRes as any, mockNext);

      expect(service.login).toHaveBeenCalledWith(mockReq.body);
      expect(mockRes.status).toHaveBeenCalledWith(HttpStatusCode.Ok);
      expect(mockRes.json).toHaveBeenCalledWith({
        status: true,
        statusCode: HttpStatusCode.Ok,
        message: 'Login successfully',
        data: {
          token: mockToken,
          user: mockUser,
        },
      });
    });

    it('should call next with error if login fails', async () => {
      const error = new Error('Login failed');
      jest.spyOn(service, 'login').mockRejectedValue(error);

      await controller.login(mockReq as Request, mockRes as any, mockNext);

      expect(mockNext).toHaveBeenCalledWith(error);
    });
  });

  describe('getUserDetailsByToken', () => {
    it('should return mapped user details', async () => {
      const mappedUser = { id: 'user-123', name: 'Test' };

      mockRes.locals.currentUser = {};

      jest.spyOn(service, 'mapUserResponse').mockReturnValue(mappedUser as any);

      await controller.getUserDetailsByToken(
        {} as any,
        mockRes as any,
        mockNext
      );

      expect(mockRes.status).toHaveBeenCalledWith(HttpStatusCode.Ok);
      expect(mockRes.json).toHaveBeenCalledWith({
        status: true,
        statusCode: HttpStatusCode.Ok,
        message: 'Authorized user details fetched successfully',
        data: mappedUser,
      });
    });

    it('should call next on exception', async () => {
      const error = new Error('Something went wrong');
      mockRes.locals.currentUser = {};

      jest.spyOn(service, 'mapUserResponse').mockImplementation(() => {
        throw error;
      });

      await controller.getUserDetailsByToken(
        {} as any,
        mockRes as any,
        mockNext
      );

      expect(mockNext).toHaveBeenCalledWith(error);
    });
  });
});
