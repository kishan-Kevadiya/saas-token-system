import { type CurrentUserDto } from '../auth/dto/current-user.dto';
import { type UserResponseDto } from '../user-auth/dto/current-user-auth.dto';
import { type CounterDropDownListDto } from './dto/counter-dropdown-list.dto';
import { type CounterResponseBodyDto } from './dto/counter.dto';
import prisma from '@/lib/prisma';

export default class CounterService {
  public async getCounterByCompanyId(
    currentUser: CurrentUserDto
  ): Promise<CounterResponseBodyDto> {
    const counterResult = await prisma.ht_counter_filter.findMany({
      where: {
        company_id: currentUser.id,
        deleted_at: null,
      },
      select: {
        hash_id: true,
        counter_no: true,
        counter_name: true,
      },
    });

    return {
      counter: counterResult.map((counter) => ({
        id: counter.hash_id,
        counter_no: counter.counter_no,
        counter_name: counter.counter_name,
      })),
    };
  }

  public async getCouterService(hashId: string) {
    const counter = await prisma.ht_counter_filter.findUnique({
      where: {
        hash_id: hashId,
        deleted_at: null,
      },
      select: {
        company_id: true,
        series: true,
        id: true,
      },
    });

    if (!counter) throw Error('Counter not found!');

    return {
      id: counter.id,
      series_ids: counter.series.split(','),
      company_id: counter.company_id,
    };
  }

  public async counterListForDropDown(
    currentUser: UserResponseDto
  ): Promise<CounterDropDownListDto[]> {
    const counterDropDownList = await prisma.ht_counter_filter.findMany({
      where: {
        company_id: currentUser.company.id,
        dept_id: currentUser.department?.id,
        is_logged_in: 1,
      },
      select: {
        hash_id: true,
        counter_name: true,
        counter_no: true,
      },
    });

    return counterDropDownList.map((counterList) => ({
      id: counterList.hash_id,
      counter_name: counterList.counter_name,
      counter_no: counterList.counter_no,
    }));
  }
}
