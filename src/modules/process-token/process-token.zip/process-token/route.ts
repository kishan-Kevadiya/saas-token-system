import { Router } from 'express';
import auth from './company-auth/auth.route';
import counter from './counter/counter.route';
import userAuth from './user-auth/user-auth.route';
import token from './token/token.route';
import buttons from './button/button.route';
import departments from './department/department.route';
import settings from './settings/settings.route';

const processTokenRoutes: Router = Router();

processTokenRoutes.use('/auth', auth);
processTokenRoutes.use('/user-auth', userAuth);

processTokenRoutes.use('/counter', counter);
processTokenRoutes.use('/token-status', token);
processTokenRoutes.use('/buttons', buttons);
processTokenRoutes.use('/department', departments);
processTokenRoutes.use('/settings', settings);

export default processTokenRoutes;
