export const createUserBody = {
  name: 'John',
  phone: '+99999999999999',
  email: 'john@example.com',
};
