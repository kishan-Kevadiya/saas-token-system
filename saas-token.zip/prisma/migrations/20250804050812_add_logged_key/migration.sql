-- AlterTable
ALTER TABLE `ht_counter_filter` ADD COLUMN `is_logged_in` TINYINT NOT NULL DEFAULT 0;
