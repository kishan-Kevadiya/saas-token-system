document.getElementById('go-back').addEventListener('click', () => {
  history.back();
});

document.getElementById('leave').addEventListener('click', () => {
  window.location.href = 'https://youtu.be/dQw4w9WgXcQ';
});
