import { IsOptional, IsString } from 'class-validator';

export class tokenStatusUpdateDto {
  @IsString()
  status: string;

  @IsOptional()
  @IsString()
  transfer_counter_id?: string;

  @IsOptional()
  @IsString()
  transfer_department_id?: string;

  @IsOptional()
  @IsString()
  reason?: string;
}
