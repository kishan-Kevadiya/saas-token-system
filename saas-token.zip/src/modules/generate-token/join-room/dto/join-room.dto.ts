// import { IsString } from 'class-validator';

// export class generate-token/join-roomjoin-roomDto {
//   @IsString()
//   id: string;
// }
