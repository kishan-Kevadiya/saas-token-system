export const LOG_DIR = './logs';
export const LOG_DATE_FORMAT = 'MM-DD-YYYY HH:MM:SS';
export const DEFAULT_PORT = 5000;
