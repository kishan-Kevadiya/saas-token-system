import { type NextFunction } from 'express';
import { type Socket } from 'socket.io';
import { validateGenerateSocketTokenUser } from './validate-generate-token-user';
import { SocketNamespace } from '@/enums/socket.enum';

export const SocketUserValidators: Record<
  SocketNamespace,
  (token: string) => Promise<any>
> = {
  [SocketNamespace.GENERATE_TOKEN]: validateGenerateSocketTokenUser,
  [SocketNamespace.PROCESS_TOKEN]: validateGenerateSocketTokenUser,
};

export const socketAuthMiddleware = (authModuleType) => {
  return async (socket: Socket, next: NextFunction) => {
    try {
      const token = socket.handshake.auth.token ?? socket.handshake.query.token;
      console.log('token', token);
      if (!token) {
        throw new Error('Authentication token missing');
      }

      console.log(authModuleType);
      const user = await SocketUserValidators[authModuleType](token);
      socket.data.user = user;

      next();
    } catch (error) {
      next(new Error('Authentication failed'));
    }
  };
};
